Usuarios y contraseñas en la base de datos:

admin, admin
Pedrito, passpedro
Joselito, passjose